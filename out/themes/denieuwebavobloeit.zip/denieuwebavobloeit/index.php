<?php
/**
 * Created by PhpStorm.
 * User: Maarten Kools
 * Date: 3/27/2015
 * Time: 7:57 PM
 */ 
require_once(get_template_directory().'/index.php');
